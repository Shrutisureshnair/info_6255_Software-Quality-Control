package package1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestScenarios {
	
	public static void main (String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://northeastern.sharepoint.com/sites/studenthub");
		
		driver.manage().window().maximize();
	}

}
