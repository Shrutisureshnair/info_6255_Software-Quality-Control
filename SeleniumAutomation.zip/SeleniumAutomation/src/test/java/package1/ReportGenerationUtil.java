package package1;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ReportGenerationUtil {
    
    private static final String FOLDER_PATH = "/Users/shrutinair/Desktop/seleniumproject/ProjectEvidence/";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
    private static final String SCREENSHOT_FILE_FORMAT = ".png";
    private static final String FILE_SEPARATION = "_";

    public String createFolder(String testCaseName) {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String tcName = testCaseName + FILE_SEPARATION + dateFormat.format(timestamp);

        //Instantiate the File class   
        File f = new File(FOLDER_PATH + tcName); 
        boolean bool = f.mkdir(); 

        if (bool) {
            System.out.println("Folder is created successfully");
            return tcName;
        }
        return "Error_In_Folder_Creation";
    }

    public void screenshot(WebDriver driver, String tcName, String imageName, String step) {
        TakesScreenshot scrShot =((TakesScreenshot)driver);
        File srcFile = scrShot.getScreenshotAs(OutputType.FILE);

        String path = FOLDER_PATH + tcName + "/" + imageName + FILE_SEPARATION + step + SCREENSHOT_FILE_FORMAT;

        //Move image file to new destination
        File destFile=new File(path);
        //Copy file at destination
        try {
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException e) {
            System.out.println("Error when taking screenshot " + e);
        }
    }
    
    //code for html to pdf generation
    public static void pageToPdf(String htmlText, String fileName) throws IOException {

		
		PdfDocument pdf = new PdfDocument(new PdfWriter(fileName + ".pdf"));
		FileOutputStream outputStream = new FileOutputStream(fileName + ".pdf");
		HtmlConverter.convertToPdf(htmlText, outputStream);
		outputStream.close();
		pdf.close();

		System.out.println("PDF created successfully!");
	}


}
