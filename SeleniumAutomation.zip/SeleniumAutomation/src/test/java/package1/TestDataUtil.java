package package1;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.poi.ss.usermodel.Cell;

import java.io.UnsupportedEncodingException;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;

public class TestDataUtil {

    private static final String FILE_PATH = "/Users/shrutinair/Desktop/seleniumproject/SeleniumProject.xlsx";

    //Read test case name or test data
    public String readTestData(String sheetName, int rowNumber, int cellNUmber) {
        try {
            FileInputStream fs = new FileInputStream(FILE_PATH);
            XSSFWorkbook workbook = new XSSFWorkbook(fs);
            XSSFSheet sheet = workbook.getSheet(sheetName);
            Row row = sheet.getRow(rowNumber);
            Cell cell = row.getCell(cellNUmber);
            return cell.getStringCellValue();
        } catch (IOException ex) {
            System.out.println("Error while reading test case name" + ex);
            System.out.println("File path" + FILE_PATH);
        }
        return "NO_TEST_CASE"; 
    }

    //Read Password
    public String readPassword(String sheetName, int rowNumber, int cellNUmber) {
        try {
            FileInputStream fs = new FileInputStream(FILE_PATH);
            XSSFWorkbook workbook = new XSSFWorkbook(fs);
            XSSFSheet sheet = workbook.getSheet(sheetName);
            Row row = sheet.getRow(rowNumber);
            Cell cell = row.getCell(cellNUmber);
            byte[] bytes;
            bytes = Hex.decodeHex(cell.getStringCellValue().toCharArray());
            return new String(bytes, "UTF-8");
        } catch (IOException  ex) {
            System.out.println("Error while reading password from test data" + ex);
            System.out.println("File path" + FILE_PATH);
        } catch (DecoderException ex) {
            System.out.println("Error while reading password from test data" + ex);
            System.out.println("File path" + FILE_PATH);
        }
        return ""; 
    }

    //Write the expected and status of test cases in the spreadsheet
    public void write(String sheetName, String data, int rowNumber, int cellNumber) {
        try {
            FileInputStream fs = new FileInputStream(FILE_PATH);
            XSSFWorkbook workbook = new XSSFWorkbook(fs);
            XSSFSheet sheet = workbook.getSheet(sheetName);
            Row row = sheet.getRow(rowNumber);
            Cell cell = row.getCell(cellNumber);
            cell.setCellValue(data);
        } catch (IOException ex) {
            System.out.println("File initialization failed" + ex);
            System.out.println("File path" + FILE_PATH);
        }
    }
}
