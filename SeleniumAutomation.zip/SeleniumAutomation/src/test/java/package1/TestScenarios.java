package package1;
import org.testng.annotations.AfterMethod;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Pdf;
import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.print.PrintOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.time.Duration;

import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.google.common.io.Files;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import java.util.*;


@Test
public class TestScenarios {
	
	WebDriver driver;
	private static final String DIR = "/Users/shrutinair/Desktop/seleniumproject/ProjectEvidence/";
    ExtentSparkReporter htmlReporter = new ExtentSparkReporter(DIR + "Report.html");
    ExtentReports extent;
    //helps to generate the logs in the test report.
    ExtentTest test;
    
    TestDataUtil testDataUtil = new TestDataUtil();
    ReportGenerationUtil reportUtil = new ReportGenerationUtil();
    private static String username = "";
    private static String password = "";
	
	@BeforeClass
	public void Scenario1() {
		
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        //configuration items to change the look and feel
        //add content, manage tests etc
        htmlReporter.config().setDocumentTitle("Simple Automation Report");
        htmlReporter.config().setReportName("Test Report");
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
		
		System.setProperty("webdriver.chrome.driver", "/Users/shrutinair/Desktop/seleniumproject/chromedriver");
		 System.setProperty("webdriver.http.factory", "jdk-http-client");
         ChromeOptions options = new ChromeOptions();
         options.addArguments("--remote-allow-origins=*");
         options.addArguments("--headless");

		//creating an instance web driver
		 driver = new ChromeDriver();
		
		 // Maximize the browser
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().deleteAllCookies();
        
        username = testDataUtil.readTestData("TestData", 1, 2);
        password = testDataUtil.readPassword("TestData", 1, 3);
   
	}
	
	@Test(priority = 1)
	public void downloadTranscripts() throws InterruptedException {
		
		String email = testDataUtil.readTestData("TestData", 1, 8);
		
		String tcNum = testDataUtil.readTestData("TestScenarios", 1, 1);
		String scenario = testDataUtil.readTestData("TestScenarios", 1, 2);
		String fullTcName = reportUtil.createFolder(tcNum + "_" + scenario);
		test = extent.createTest(fullTcName, "Transcripts should be downloaded and saved as pdf successfully");

		  driver.get("https://my.northeastern.edu/");
		  reportUtil.screenshot(driver, fullTcName, "MyNEUpage", "Before");
		  Thread.sleep(5000);
		  
		  test.log(Status.PASS, "NEU Login");
		  
		  //click the login button
		  driver.findElement(By.xpath("//*[@id=\"portlet_com_liferay_journal_content_web_portlet_JournalContentPortlet_INSTANCE_7SMCIHKvD44Y\"]/div/div/div/div[2]/div/div[2]/div/a")).click();
		  

		  Thread.sleep(10000);
		  
		  // Student hub page
		  reportUtil.screenshot(driver, fullTcName, "StudentHub", "");
		  Thread.sleep(10000);
		  System.out.println(driver.getCurrentUrl());
		  
		  test.log(Status.PASS, "User logins to Student hub page");
		  
		  driver.get("https://me.northeastern.edu");
		  Thread.sleep(10000);
		  
		  //Click on Active directory
		  driver.findElement(By.xpath("//*[@id=\"bySelection\"]/div[3]/div")).click();
		  Thread.sleep(5000);
		  
		  //Enter credentials in active directory
		  reportUtil.screenshot(driver, fullTcName, "StudenthubLoginPage", "Before");
		  driver.findElement(By.xpath("//*[@id=\"userNameInput\"]")).sendKeys(email);
		  driver.findElement(By.xpath("//*[@id=\"passwordInput\"]")).sendKeys(password);
		  reportUtil.screenshot(driver, fullTcName, "StudenthubLoginPage", "After");
		  
		  Thread.sleep(5000);
		  driver.findElement(By.xpath("//*[@id=\"submitButton\"]")).click();
		  Thread.sleep(20000);
		  
		  //yes button
		  reportUtil.screenshot(driver, fullTcName, "Authentication", "");
		  driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click();
		  
		  //click on Resources
		  reportUtil.screenshot(driver, fullTcName, "StudentHub", "");
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(By.xpath("//*[@id=\"spSiteHeader\"]/div/div[2]/div/div[3]/div/div/div/span[4]/a/span")).click();
		  
		  test.log(Status.PASS, "User clicks on resource tab");
		  
		  //click Academic classes and registration
		  reportUtil.screenshot(driver, fullTcName, "Registration", "");
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(By.xpath("//*[@id=\"7b3083e7-1956-4f64-968b-920d938ba636\"]/div/div/div/div[1]/div[2]/div/div[1]/div/p")).click();
		  
		  //Click on My Transcripts
		 
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(By.xpath("//*[@id=\"7b3083e7-1956-4f64-968b-920d938ba636\"]/div/div/div/div[2]/div/div/div[2]/div[1]/div/div/div[1]/div/div/a")).click();
		  reportUtil.screenshot(driver, fullTcName, "Transcripts", "Before");
		  
		  test.log(Status.PASS, "User click on My Transcript");
		  
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  //window handler
		  ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		  driver.switchTo().window(tabs2.get(1));
		  
		  // login page
		  reportUtil.screenshot(driver, fullTcName, "LoginPage", "Before");
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(username);
		  driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
		  reportUtil.screenshot(driver, fullTcName, "LoginPage", "After");
		  Thread.sleep(2000);
		  
		  driver.findElement(By.xpath("/html/body/section/div/div[1]/div/form/div[3]/button")).click();
		  Thread.sleep(2000);
		  
		  
		  //Window handler code
		  ArrayList<String> tabs3 = new ArrayList<String> (driver.getWindowHandles());
		  driver.switchTo().window(tabs3.get(1));
		  	
		  // Select Transcript level
		  driver.findElement(By.xpath("//*[@id=\"levl_id\"]")).click();
		  Thread.sleep(2000);
		  
		  driver.findElement(By.xpath("//*[@id=\"levl_id\"]/option[2]")).click();
		  Thread.sleep(2000);
		  
		  //Select Transcript Type
		  driver.findElement(By.xpath("	//*[@id=\"type_id\"]")).click();
		  Thread.sleep(2000);
		  
		  driver.findElement(By.xpath("//*[@id=\"type_id\"]/option[1]")).click();
		  Thread.sleep(2000);
		  
	
		  // click on submit
	      WebElement element = driver.findElement(By.xpath("//input[@value='Submit']"));
		  element.click();
		  Thread.sleep(1000);
		  reportUtil.screenshot(driver, fullTcName, "Transcripts", "After");
		  
		  test.log(Status.PASS, "User click on submit for viewing transcript");

		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  
		  //Print pdf code
		  try {
			ReportGenerationUtil.pageToPdf(driver.findElement(By.xpath("/html/body")).getAttribute("innerHTML"), "Transcript");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		  test.pass(MediaEntityBuilder.createScreenCaptureFromPath(DIR + fullTcName + "/" + "Transcripts_After.png").build());
			
		  
	}
	
	@Test(priority = 2)
	public void AddToDoTask() throws InterruptedException {
		String eventTitle = testDataUtil.readTestData("TestData", 2, 4);
		String eventDate = testDataUtil.readTestData("TestData", 2, 5);
		String eventTime = testDataUtil.readTestData("TestData", 2, 6);
		
		String tcNum = testDataUtil.readTestData("TestScenarios", 2, 1);
		String scenario = testDataUtil.readTestData("TestScenarios", 2, 2);
		
		String fullTcName = reportUtil.createFolder(tcNum + "_" + scenario);
		
		test = extent.createTest(fullTcName, "Event should be added to the calendar successfully");
		
		driver.get("https://canvas.northeastern.edu/");
		reportUtil.screenshot(driver, fullTcName, "Canvas", "Before");
		
		// Canvas login Page
		String title = driver.getTitle();
		AssertJUnit.assertEquals(title, "Canvas at Northeastern");
		test.log(Status.PASS, "Canvas Page");
		
		driver.findElement(By.xpath("//*[@id=\"menu-item-menu-main-desktop-4343\"]/a/span")).click();
		
		Thread.sleep(10000);
		
		//Click on the calendar icon
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		reportUtil.screenshot(driver, fullTcName, "Dashboard", "Before");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"global_nav_calendar_link\"]")).click();
		reportUtil.screenshot(driver, fullTcName, "Dashboard", "After");
		Thread.sleep(1000);
		
		//click on the + icon
		driver.findElement(By.xpath("//*[@id=\"create_new_event_link\"]")).click();
		
		test.log(Status.PASS, "User click on calendar icon");
		//Click on My to Do
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.xpath("//*[@id=\"ui-id-5\"]")).click();
		reportUtil.screenshot(driver, fullTcName, "EventCreation", "Before");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		// Enter title
		driver.findElement(By.xpath("//*[@id=\"planner_note_title\"]")).sendKeys(eventTitle);
		//Select date
		driver.findElement(By.xpath("//*[@id=\"planner_note_date\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"planner_note_date\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"planner_note_date\"]")).sendKeys(eventDate);
		//select time
		driver.findElement(By.xpath("//*[@id=\"planner_note_time\"]")).sendKeys(eventTime);
		
		reportUtil.screenshot(driver, fullTcName, "EventCreation", "After");
		
		
		test.log(Status.PASS, "User fill event details");
		
		//click on submit button
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"edit_planner_note_form_holder\"]/form/div[2]/button")).click();
		
		//click on the saved event
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"calendar-app\"]/div[4]/div/div/table/tbody/tr/td/div/div/div[5]/div[2]/table/tbody/tr[2]/td[2]/a")).click();
		reportUtil.screenshot(driver, fullTcName, "Result", "");
		test.pass(MediaEntityBuilder.createScreenCaptureFromPath(DIR + fullTcName + "/" + "Result_.png").build());
		
		test.log(Status.PASS, "User view created event");
		
		//verify the title of the event
		Thread.sleep(5000);
		String result = driver.findElement(By.xpath("//*[@id=\"event-details-trap-focus\"]/div[1]/h2")).getText();
		AssertJUnit.assertEquals(eventTitle,result);
	}
	
	@Test(priority =3)
	public void downloadTestGuide() throws InterruptedException {
		
		 driver = new ChromeDriver();
			
		 // Maximize the browser
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().deleteAllCookies();
		
		String pdfText = testDataUtil.readTestData("TestData", 3, 7);
		
		String tcNum = testDataUtil.readTestData("TestScenarios", 3, 1);
		String scenario = testDataUtil.readTestData("TestScenarios", 3, 2);
		String fullTcName = reportUtil.createFolder(tcNum + "_" + scenario);
		test = extent.createTest(fullTcName, "The Quick guide pdf should be downloaded successfully");
		
		
		driver.get("https://service.northeastern.edu/tech?id=classrooms");
		Thread.sleep(5000);
		reportUtil.screenshot(driver, fullTcName, "NEUpage", "After");
		test.log(Status.PASS, "NEU Technology services Page");
		
			//Enter the username , password and hit login
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			reportUtil.screenshot(driver, fullTcName, "LoginPage", "Before");
			driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(username);
			driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
			reportUtil.screenshot(driver, fullTcName, "LoginPage", "After");
			test.log(Status.PASS, "User Login");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
			driver.findElement(By.xpath("/html/body/section/div/div[1]/div/form/div[3]/button")).click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			
			//click on the classroom tab
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			test.log(Status.PASS, "Classroom page");
			reportUtil.screenshot(driver, fullTcName, "Homepage", "Before");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id=\"x9e306771db089110ebcdcafc13961963\"]/div/ul/li[2]/span/a")).click();
					
			//select a classroom
			reportUtil.screenshot(driver, fullTcName, "Homepage", "After");
			driver.findElement(By.xpath("//*[@id=\"x77ea03d9972dd1d8beddb4221153afa6\"]/div/div[2]/span/div/div/div[1]/div/div/div/a")).click();
			
	
			// verify the Quick guide pdf text
			test.log(Status.PASS, "Guide page");
			reportUtil.screenshot(driver, fullTcName, "QuickGuide", "Before");
			String result = driver.findElement(By.xpath("//*[@id=\"x51d2fa949721d518beddb4221153af23\"]/div/div[2]/span/table[1]/tbody/tr[1]/td[1]")).getText();
			AssertJUnit.assertEquals(result, pdfText);
			
			//click on the quick guide pdf
			Thread.sleep(2000);
			driver.findElement(By.xpath("/html/body/div/section/main/div/div/sp-page-row/div/div[1]/span/div/div/div[2]/span/table[1]/tbody/tr[1]/td[2]/a")).click();
			Thread.sleep(3000);
			//Window handler code
			  ArrayList<String> tabs3 = new ArrayList<String> (driver.getWindowHandles());
			  driver.switchTo().window(tabs3.get(1));
			reportUtil.screenshot(driver, fullTcName, "QuickGuide", "After");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			test.pass(MediaEntityBuilder.createScreenCaptureFromPath(DIR + fullTcName + "/" + "QuickGuide_After.png").build());
			test.log(Status.PASS, "PDF generation");
			
	}
	
	@Test(priority=4)
	public void downloadDatasets() throws InterruptedException {
		String tcNum = testDataUtil.readTestData("TestScenarios", 4, 1);
		String scenario = testDataUtil.readTestData("TestScenarios", 4, 2);
		
		String fullTcName = reportUtil.createFolder(tcNum + "_" + scenario);
		
		test = extent.createTest(fullTcName, "Dataset should be downloaded successfully");
		
		  reportUtil.screenshot(driver, fullTcName, "NEULibraryPage", "");
		  driver.get("https://onesearch.library.northeastern.edu/discovery/search?vid=01NEU_INST:NU&lang=en");
		  test.log(Status.PASS, "NEU Library page");
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//click on digital repository
		
		reportUtil.screenshot(driver, fullTcName, "DigitalRepo", "Before");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"mainMenu\"]/div[5]/a")).click();
		 reportUtil.screenshot(driver, fullTcName, "DigitalRepo", "After");
		 test.log(Status.PASS, "Digital Repository page");
		Thread.sleep(10000);
		
		//Window handler code
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(2));
		 System.out.println(driver.getCurrentUrl());
		  
		//click on dataset
		
		reportUtil.screenshot(driver, fullTcName, "DataSetPage", "Before");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("/html/body/div[1]/main/div[1]/section/div[1]/a[5]")).click();
		test.log(Status.PASS, "Dataset Page");
		Thread.sleep(2000);
		reportUtil.screenshot(driver, fullTcName, "DataSetPage", "After");
		
		//click on the zip file
		Thread.sleep(2000);
		reportUtil.screenshot(driver, fullTcName, "Download", "Before");
		test.log(Status.PASS, "ZipFolder Page");
		driver.findElement(By.xpath("//*[@id=\"main-content\"]/div[2]/main/section/ul/article[1]/div/div/div/div/div[1]/a[1]")).click();
		reportUtil.screenshot(driver, fullTcName, "Download", "After");
		test.log(Status.PASS, "Download Zip");
		test.pass(MediaEntityBuilder.createScreenCaptureFromPath(DIR + fullTcName + "/" + "Download_After.png").build());
	}
	
	@Test(priority = 5)
	public void jobAlert() throws InterruptedException {
		
		String tcNum = testDataUtil.readTestData("TestScenarios", 5, 1);
		String scenario = testDataUtil.readTestData("TestScenarios", 5, 2);
		
		String fullTcName = reportUtil.createFolder(tcNum + "_" + scenario);
		
		test = extent.createTest(fullTcName, "Subscription should be created Successfully");
		
		
		//login to workday
		reportUtil.screenshot(driver, fullTcName, "Workday", "Before");
		
		driver.get("https://studentemployment.northeastern.edu/");
		Thread.sleep(10000);
		
		//Click on go to workday
		driver.findElement(By.xpath("//*[@id=\"post-2\"]/div/div/div/div[1]/div[3]/div[3]/div/a")).click();
		Thread.sleep(20000);
		test.log(Status.PASS, "Click on Workday");
		

		
		//click on remember and submit
		reportUtil.screenshot(driver, fullTcName, "Authorization", "Before");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.findElement(By.xpath("//*[@id=\"tdCheckbox\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"submitButton\"]")).click();
		Thread.sleep(2000);
		reportUtil.screenshot(driver, fullTcName, "Authorization", "After");
		Thread.sleep(1000);
		test.log(Status.PASS, "Authorization");
		
		//Click the menu
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		reportUtil.screenshot(driver, fullTcName, "menu option", "");
		driver.findElement(By.xpath("//*[@id=\"app-chrome-container\"]/div/div[6]/div[1]/div[1]/button")).click();
		test.log(Status.PASS, "Click the menu");
		
		//Click Jobs and application
		 Thread.sleep(2000);
		 reportUtil.screenshot(driver, fullTcName, "jobs and application", "");
		driver.findElement(By.xpath("/html/body/div[5]/div/div/div[2]/div[3]/div[2]/div/div[2]/div/ul/li[3]/a")).click();
		test.log(Status.PASS, "Click Jobs and application");
		
		// click on students employment
		reportUtil.screenshot(driver, fullTcName, "student employment page", "");
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]/section/div/div/div/div[1]/div/div[2]/div/div[1]/ul/li[2]/div[2]")).click();
		test.log(Status.PASS, "Click on students employment");
		
		//Click NEU Student link
		reportUtil.screenshot(driver, fullTcName, "NEU Student link", "Before");
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]/section/div/div/div/div[1]/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[4]/div[1]/div/div/div[2]/div/div[2]/ul/li/div/div/div")).click();
		reportUtil.screenshot(driver, fullTcName, "NEU Student link", "After");
		test.log(Status.PASS, "Click on NEU student link ");
		
		
		//window controller
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		 driver.switchTo().window(tabs2.get(3));
		
		 // click on students
		 reportUtil.screenshot(driver, fullTcName, "Click on Students", "");
		driver.findElement(By.xpath("/html/body/div[3]/div[3]/nav/div/div/ul/li[2]")).click();
		test.log(Status.PASS, "Click on students");
		
		
		//click on my job mail
		reportUtil.screenshot(driver, fullTcName, "Click on my job", "");
		driver.findElement(By.xpath("/html/body/div[3]/div[3]/nav/div/div/ul/li[2]/ul/li[2]")).click();
		test.log(Status.PASS, "Click on my job mail");
		
		//Log in details
		reportUtil.screenshot(driver, fullTcName, "Loginpage", "Before");
		driver.findElement(By.xpath("/html/body/div[3]/div[6]/form/table[1]/tbody/tr[2]/td[2]/input")).sendKeys(username);
		driver.findElement(By.xpath("/html/body/div[3]/div[6]/form/table[1]/tbody/tr[3]/td[2]/input")).sendKeys(password);
		reportUtil.screenshot(driver, fullTcName, "Loginpage", "After");
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[3]/div[6]/form/table[1]/tbody/tr[4]/td[2]/input")).click();
		test.log(Status.PASS, "Login page");
		
		Thread.sleep(1000);
		//Click on Add new job description main
		reportUtil.screenshot(driver, fullTcName, "Add New Job Description", "Before");
		driver.findElement(By.xpath("//*[@id=\"Skin_body_JobMailShell_AddNew_8\"]")).click();
		Thread.sleep(2000);
		reportUtil.screenshot(driver, fullTcName, "Add New Job Description", "After");
		test.log(Status.PASS, "Click on Add new job description");
		
		//Click on view/modify button of Employer
		reportUtil.screenshot(driver, fullTcName, "Click View/Modify button of employer", "Before");
		driver.findElement(By.xpath("/html/body/div[3]/div[6]/form/table[2]/tbody/tr[2]/td[2]/table/tbody/tr[3]/td/table/tbody/tr[1]/td[5]/button")).click();
		Thread.sleep(2000);
		reportUtil.screenshot(driver, fullTcName, "Click View/Modify button of employer", "After");
		test.log(Status.PASS, "Click on View/modify button of employer");
		
		//Click on Add button of Employer
		reportUtil.screenshot(driver, fullTcName, "Click on Add button", "");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div[1]/div[2]/a")).click();
		test.log(Status.PASS, "Click on add button of employer");
	
		
		//Click on the save button
		reportUtil.screenshot(driver, fullTcName, "Click on Save button", "");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[4]/button")).click();
		Thread.sleep(2000);
		test.log(Status.PASS, "Click on save button of employer");
		
		// Click on modify button of category
		reportUtil.screenshot(driver, fullTcName, "Click on view/modify button of category", "Before");
		driver.findElement(By.xpath("/html/body/div[3]/div[6]/form/table[2]/tbody/tr[2]/td[2]/table/tbody/tr[3]/td/table/tbody/tr[2]/td[5]/button")).click();
		Thread.sleep(2000);
		reportUtil.screenshot(driver, fullTcName, "Click on view/modify button of category", "After");
		test.log(Status.PASS, "Click on View/modify button of category");
		
		
		//Click on the add
		reportUtil.screenshot(driver, fullTcName, "Click on Add button", "");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div[1]/div[2]/a")).click();
		test.log(Status.PASS, "Click on add button of category");
		
		//Click on save button
		reportUtil.screenshot(driver, fullTcName, "Click on save button", "");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[4]/button")).click();
		Thread.sleep(2000);
		test.log(Status.PASS, "Click on save button of category");
		
		//Click on modify button of modify button Time frame
		reportUtil.screenshot(driver, fullTcName, "Click on view/modify button of Time frame", "Before");
		driver.findElement(By.xpath("/html/body/div[3]/div[6]/form/table[2]/tbody/tr[2]/td[2]/table/tbody/tr[3]/td/table/tbody/tr[3]/td[5]/button")).click();
		Thread.sleep(2000);
		reportUtil.screenshot(driver, fullTcName, "Click on view/modify button of Time frame", "After");
		test.log(Status.PASS, "Click on View/modify button of Time frame");
		
		//Click on Add button
		reportUtil.screenshot(driver, fullTcName, "Click on add button", "");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[3]/div[1]/div[2]/a")).click();
		test.log(Status.PASS, "Click on Add button of Time frame");
		
		//Click on save
		reportUtil.screenshot(driver, fullTcName, "Click on save button", "");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[4]/button")).click();
		Thread.sleep(1000);
		test.log(Status.PASS, "Click on save button of Time frame");
		
		//Click on save subscription
		reportUtil.screenshot(driver, fullTcName, "SaveSubscription", "Before");
		driver.findElement(By.xpath("/html/body/div[3]/div[6]/form/div[4]/input")).click();
		reportUtil.screenshot(driver, fullTcName, "SaveSubscription", "After");
		Thread.sleep(2000);
		test.log(Status.PASS, "SaveSubscription");
		test.pass(MediaEntityBuilder.createScreenCaptureFromPath(DIR + fullTcName + "/" + "SaveSubscription_After.png").build());
			
		
	}
	
	
	@AfterClass
	public void tearDown() {
		
		driver.quit();
		extent.flush();
	}

}
